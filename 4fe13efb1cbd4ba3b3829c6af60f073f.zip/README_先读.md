# 排列三：GitHub Actions 构建配套包

这不是另一份App源码。请与上一条下载的《排列三_全维度Android源码_独立完整版.zip》一起使用。
本包不包含上一条App工程；当前会话环境未保留它，不会用空工程冒充完整App。

## 最省事：网页操作
1. 新建GitHub仓库（私人/公开均可，需允许GitHub Actions）。
2. 把上一条完整安卓源码ZIP上传到仓库根目录。不需要解压源码ZIP。
3. 点 Add file → Create new file，文件名填写 `.github/workflows/android-build.yml`。
4. 把本包附带的android-build.yml完整内容复制进去，提交到默认分支。
5. 打开Actions，选择Build PL3 Android APK。提交通常自动触发；也可Run workflow手动触发。
6. 若仓库根目录有且仅有一个有效Android源码ZIP，两个输入留空即可。多个源码包时，source_zip输入完整文件名。
7. 成功后进入该次运行页面，在Artifacts中取pl3-debug-apk-序号。这个制品是ZIP，解压得到APK。

注意：只上传“GitHub构建配套包.zip”不会触发Actions，工作流YAML必须真实存在于仓库的.github/workflows目录。源码ZIP可以保持压缩状态，是工作流负责解压；工作流自身不能仍然压缩在ZIP里。

## 本地Git方式
解压本包，把.github目录复制到仓库根目录，再放入完整源码ZIP后提交。ci/prepare_source.py为相同引导代码的独立版本，工作流已经内嵌它，因此不上传ci目录也能工作。

## 同样支持已解压工程
目录可以是：
.github/workflows/android-build.yml
PL3AllMetrics/settings.gradle.kts
PL3AllMetrics/app/...
无需手工把工程挪到仓库根目录。若多工程，手动触发时用project_dir指定。

## 构建流程
Java17、Android SDK35、Build Tools35.0.0、Gradle8.9；无需已提交Gradle Wrapper。
依次执行可选Python历史回归脚本，再执行:
gradle --no-daemon --console=plain --stacktrace :app:testDebugUnitTest :app:assembleDebug
测试或编译失败会让整个运行失败，不伪装成功；构建日志/测试报告尽量总是上传。只有真正成功构建才上传APK。

## 边界
- 生成的是自动Debug签名APK，用于测试安装。不是商店Release包，不含固定正式签名或AAB。
- 不同运行的临时Debug签名不保证相同，不能保证覆盖安装之前的版本；如需长期更新应另配固定密钥与Secrets。
- 没有向用户GitHub创建仓库或上传文件；所有内容仅本地交付。
- 当前环境没有Java/Gradle/SDK，未实际运行GitHub Actions，也未证明App源码编译通过。
- 本次实际测试了：已解压工程识别、源码ZIP解压识别、恶意ZIP路径越界拒绝。详见bootstrap_test_results.json。
- 构建成功也不等于开奖数据源已经接入、后台调度已真机验收或统计模型已经证明有效。
- 第三方Actions按版本标签引用；生产环境可另行固定经审查的commit SHA。
- 需要账户Actions可用额度及网络下载依赖，不能保证零费用。

## 排错
找不到Run workflow：确认工作流已提交到默认分支。
找不到源码：上传完整安卓源码ZIP，不是CSV、统计报告或本构建包。
多个源码：指定source_zip，或project_dir。
Kotlin/测试错误：获取Artifacts中的pl3-build-reports或打开对应失败步骤。请提供日志后针对具体代码修复；不要跳过测试伪造通过。
依赖/SDK下载失败：查看网络或仓库服务状态后重试。
