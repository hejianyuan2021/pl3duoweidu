import os, sys, zipfile, shutil, stat
from pathlib import Path, PurePosixPath

ROOT = Path(os.environ.get("GITHUB_WORKSPACE", ".")).resolve()
EXTRACT = ROOT / ".ci-source"
MAX_BYTES = 200 * 1024 * 1024

def candidates(folder):
    paths = list(folder.rglob("settings.gradle.kts")) + list(folder.rglob("settings.gradle"))
    return sorted({p.parent.resolve() for p in paths if not any(x in {".git", ".gradle", "build", ".ci-source"} for x in p.relative_to(folder).parts) and (p.parent / "app").is_dir()})

def safe_extract(archive):
    if EXTRACT.exists(): shutil.rmtree(EXTRACT)
    EXTRACT.mkdir()
    with zipfile.ZipFile(archive) as z:
        entries = z.infolist()
        if len(entries) > 10000 or sum(i.file_size for i in entries) > MAX_BYTES:
            raise ValueError("Source ZIP too large")
        written = 0
        for item in entries:
            name = item.filename.replace("\\", "/")
            path = PurePosixPath(name)
            mode = item.external_attr >> 16
            if path.is_absolute() or ".." in path.parts or any(":" in x for x in path.parts) or stat.S_ISLNK(mode):
                raise ValueError("Unsafe archive member: " + name)
            target = (EXTRACT / name).resolve()
            target.relative_to(EXTRACT.resolve())
            if item.is_dir(): target.mkdir(parents=True, exist_ok=True); continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(item) as src, target.open("wb") as dst:
                while True:
                    chunk = src.read(65536)
                    if not chunk: break
                    written += len(chunk)
                    if written > MAX_BYTES: raise ValueError("Extracted bytes exceed limit")
                    dst.write(chunk)
    # Search under extracted root; ignore nested build output but not .ci-source itself.
    settings = list(EXTRACT.rglob("settings.gradle.kts")) + list(EXTRACT.rglob("settings.gradle"))
    return sorted({p.parent.resolve() for p in settings if (p.parent / "app").is_dir()})

archive_arg = os.environ.get("SOURCE_ZIP", "").strip()
project_arg = os.environ.get("PROJECT_DIR", "").strip()
if project_arg:
    project = (ROOT / project_arg).resolve()
    project.relative_to(ROOT)
    projects = [project]
elif archive_arg:
    archive = (ROOT / archive_arg).resolve(); archive.relative_to(ROOT)
    projects = safe_extract(archive)
else:
    projects = candidates(ROOT)
    if not projects:
        archives = sorted(ROOT.glob("*.zip"))
        usable = []
        for archive in archives:
            try:
                with zipfile.ZipFile(archive) as z:
                    if any(PurePosixPath(n).name in {"settings.gradle", "settings.gradle.kts"} for n in z.namelist()):
                        usable.append(archive)
            except zipfile.BadZipFile:
                pass
        if len(usable) != 1:
            raise SystemExit("Expected one Android source ZIP at repository root, or an extracted Android project. Use workflow input source_zip if ambiguous.")
        projects = safe_extract(usable[0])
if len(projects) != 1:
    raise SystemExit("Expected exactly one Android app project; found: " + repr(projects))
project = projects[0]
if not ((project / "settings.gradle.kts").exists() or (project / "settings.gradle").exists()):
    raise SystemExit("No settings.gradle[.kts] in selected project")
if not (project / "app").is_dir(): raise SystemExit("Missing app module")
sdk = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
if sdk:
    escaped = sdk.replace("\\", "\\\\").replace(":", "\\:")
    (project / "local.properties").write_text("sdk.dir=" + escaped + "\n", encoding="utf-8")
rel = project.relative_to(ROOT).as_posix()
if any(c in rel for c in "\r\n"): raise SystemExit("Invalid project path")
output = os.environ.get("GITHUB_OUTPUT")
if output:
    with open(output, "a", encoding="utf-8") as f: f.write("project=" + rel + "\n")
print("Selected Android project:", rel)
